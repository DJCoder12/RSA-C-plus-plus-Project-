#include <string>
#include <ostream>
#include <cmath>
#include <cstdlib>
#include "ReallyLongInt.h"
#include <iostream>
#include <climits>

using namespace std;
ReallyLongInt::ReallyLongInt()
{
  unsigned* intArray=new unsigned [1];
  intArray[0]=0;
  isNeg=false;
  digits=intArray;
  numDigits=1;
}
ReallyLongInt::ReallyLongInt(long long num)
{

  if (num==0)
    {
      unsigned* intArray=new unsigned [1];
      intArray[0]=0;
      isNeg=false;
      digits=intArray;
      numDigits=1;
      return;
       
    }
  else 
    {
     
      if (num<0)
	{
	  isNeg=true;
	  num=num*-1;
	  
	}
      else
	{
	  isNeg=false;
        
	}
      numDigits= log10(num)+1;
      unsigned* intArray=new unsigned[numDigits];
      for (int y=numDigits-1;y>=0;y--)
	{
	  intArray[y]=num%10;
	  num=num/10;
	}
      digits=intArray;
    }
}
void ReallyLongInt::removeLeadingZeros(unsigned* x, unsigned& xSize) const
{
  unsigned int iter=0;
  unsigned int starter=0;
  unsigned int bkpt=0;
  
  while(iter<xSize && x[iter]==0)
    {
      iter=iter+1;
    }
  bkpt=iter;
    if (iter==xSize)
    {      
      xSize=1;
      return;
    }
  //Dont change xSize here only change xSize at the end once you have done the movement.
    
    else 
      {
	while(iter<xSize)
	  {
	    x[starter]=x[iter];
	    iter=iter+1;
	    starter=starter+1;		     
	  }
      }
    xSize=iter-bkpt;
}

ReallyLongInt::ReallyLongInt(const string& numStr)
{
  isNeg=false;
  unsigned int index=0;
  if (numStr[0]=='-')
    {
      index=1;
      isNeg=true;
    }
  numDigits=numStr.length();
  unsigned* intArray=new unsigned[numDigits];
  intArray[0]=0;
  {
    for (;index<numDigits;index++)
      {
	intArray[index]=numStr[index]-'0';
      }
  }
  removeLeadingZeros(intArray,numDigits);
  digits=intArray;
     
}

ReallyLongInt::ReallyLongInt(const ReallyLongInt& other)
{
 
  unsigned* intArray=new unsigned [other.numDigits];
  for (unsigned int o=0;o<other.numDigits;o++)
    {
      intArray[o]=other.digits[o];
    }
  this->digits=intArray;
 
  this->numDigits=other.numDigits;
  this->isNeg=other.isNeg; 
  
}
 ostream& ReallyLongInt::print(ostream& out) const
 {
   
   if (isNeg==true)
     {
       out<<"-";
     }
  for (unsigned int z=0;z<numDigits;z++)
    {	
      out<<digits[z];	
    }
  out<<endl;
  return out;
}

void ReallyLongInt:: swap(ReallyLongInt other)
{
  std::swap(this->isNeg,other.isNeg);
  std::swap(this->numDigits,other.numDigits);
  std::swap(this->digits,other.digits);
}
ostream& operator<<(ostream& out,const ReallyLongInt& x)
{
  x.print(out);
  return out;
}
ReallyLongInt::~ReallyLongInt()
{
  delete digits;
}
ReallyLongInt ReallyLongInt:: add(const ReallyLongInt& other) const
 {
   ReallyLongInt sum;
   if (this->digits>other.digits)
     {
       sum.isNeg=this->isNeg;
     }
   else
     {
       sum.isNeg=other.isNeg;
     }

   if( (this->isNeg==true && other.isNeg==false) || (this->isNeg==false && other.isNeg==true))
     {
       ReallyLongInt sum= this->absSub(other);
       return sum;
     
     }
   else
     {
       ReallyLongInt sum=this->absAdd(other);
       return sum;
     }
  
   return sum;
 }
ReallyLongInt ReallyLongInt:: sub(const ReallyLongInt& other) const
{
  ReallyLongInt diff;
  if(this->isNeg==other.isNeg)
    {
      diff=this->absSub(other);
    }
  else
    {
      diff.flipSign();
      diff=this->absAdd(other);
    }

  return diff;

}
 
ReallyLongInt ReallyLongInt:: mult(const ReallyLongInt& other) const
{
  ReallyLongInt prod;
  if (this->isNeg==true && other.isNeg==true)
    {
      prod=this->absMult(other);
      prod.isNeg=false;
      return prod;
    }
  if((this->isNeg==false && other.isNeg==true) || (this->isNeg==true && other.isNeg==false))
    {
      prod= this->absMult(other);
      prod.isNeg=true;
      return prod;
    }
  else
    {
      prod=this->absMult(other);
      return prod;      
    }
  return prod;
}
void ReallyLongInt::div(const ReallyLongInt& denominator, ReallyLongInt& quotient, ReallyLongInt& remainder) const
{
  if ((this->isNeg==true && denominator.isNeg==false) || (this->isNeg==false && denominator.isNeg==true))
    {
      quotient.isNeg=true;
      this->absDiv(denominator,quotient, remainder);
    }
  else
    {
      this->absDiv(denominator,quotient, remainder);
    }
}

ReallyLongInt ReallyLongInt:: absAdd(const ReallyLongInt& other) const
{

  unsigned resultSize=0;
  if (this->numDigits>other.numDigits)
    {
      resultSize=this->numDigits+1;
    }
  else
    {
      resultSize=other.numDigits+1;
    }
 
  unsigned* sumArray=new unsigned [resultSize];
  for(unsigned int i = 0; i < resultSize; i ++)
    {
      sumArray[i] = 0;
    }
  unsigned long carry=0;
  unsigned int temp=0;
  for (unsigned int q=0;q<resultSize;q++)
    {
      if (q<other.numDigits)
	{
	  temp+=other.digits[other.numDigits-q-1];
	}
      if (q<this->numDigits)
	{
	  temp+=this->digits[this->numDigits-q-1];
	}

      temp+=carry;
      carry=0;
      if (temp>=10)
	{
	  temp=temp%10;
	  carry=1;
	}     
      sumArray[resultSize-1-q]=temp;
      temp=0;
    }
      
  removeLeadingZeros(sumArray,resultSize);
  ReallyLongInt* sum= new ReallyLongInt(sumArray, resultSize, isNeg);
  return *sum;
}

ReallyLongInt ReallyLongInt::absSub(const ReallyLongInt& other) const
{
  //Why does comparison not work. If you switch the comparison sign it assigns top and bottom to the correct digitsfor some reason.
  //cout<<*this>other<<endl;
  const ReallyLongInt* top;
  const ReallyLongInt* bottom;
  //This is how you refer to stuff in here
  //cout<<other<<endl;
  //cout<<*this<<endl;
  //I purposely made this the wrong sign so my code could work until tomorrow morning when I ask professor Booth
  if (this->absGreater(other))
    {
      
      top=this;
      bottom=&other;
    }
  else
    {
      
      top=&other;
      bottom=this;
    }
  //cout<<*top<<endl;
  //cout<<*bottom<<endl;
  //what do thes mean?
  //cout<<top->digits[1]<<endl;
  // Why does this give me the value for numDigits while 
  //cout<<bottom->numDigits<<endl;
  // I have to do this to get the array
  //cout<<*bottom<<endl;
  unsigned resultSize=top->numDigits;
  unsigned* difArray=new unsigned [resultSize];
  for(unsigned int i = 0; i < resultSize; i ++)
    {
      difArray[i] = 0;
    }
  //cout<<*top;
  int  borrow=0;
  int temp=0;
  for (unsigned int q=0;q<top->numDigits;q++)
    {
      temp=temp-borrow;
      temp=temp+top->digits[top->numDigits-q-1];
      if (q < bottom->numDigits)
	{
	  temp=temp-bottom->digits[bottom->numDigits-q-1];
	}
      borrow=0;
      if (temp<0)
	{
	  temp=temp+10;
	  borrow=1;
	}
   
      difArray[resultSize-1-q]=temp; 
      temp=0;
    }

  removeLeadingZeros(difArray,resultSize);
  ReallyLongInt difference=ReallyLongInt(difArray, resultSize, top->isNeg);
  cout<<difference<<endl;
  return difference;
}


   
ReallyLongInt::ReallyLongInt(unsigned* digitsArr, unsigned arrSize, bool isNeg)
{
  removeLeadingZeros(digitsArr,arrSize);
  digits=digitsArr;
  numDigits=arrSize;
  this->isNeg=isNeg;
  if (digitsArr[0]==0)
    {
      isNeg=false;
    }
}

bool ReallyLongInt:: equal(const ReallyLongInt& other) const
{
   if (this->numDigits!=other.numDigits)
     {
       return false;
     }
   else if(this->isNeg!=other.isNeg)
     {
       return false;
     }
   else
    {
      for (unsigned int v=0; v<other.numDigits;v++)
	{
	  if (this->digits[v]!=other.digits[v])
	    {
	      return false;
	    }
	}
    }

  return true;
}

bool ReallyLongInt::absGreater(const ReallyLongInt& other) const
{
   if(this->numDigits<other.numDigits)
    {
      return false;
    }
  if(this->numDigits>other.numDigits)
    {
      return true;
    }
  else
    {
      for (unsigned int q=0;q<other.numDigits; q++)
	{
	  if (this->digits[q]<other.digits[q])
	    {
	      return false;
	    }
	}
      if (equal(other))
	{
	  return false;
	}
    }
  return true;
}


ReallyLongInt ReallyLongInt:: absMult(const ReallyLongInt& other) const
{
  unsigned resultSize=other.numDigits+this->numDigits;
  unsigned int* prodArray=new unsigned int[resultSize];
  unsigned int temp=0;
  for(unsigned int i = 0; i < resultSize; i ++)
    {
      prodArray[i] = 0;
    }
  unsigned int carry;
  for (unsigned int n=0;n<this->numDigits;n++)
    {
      carry=0;
      for (unsigned int p=0; p<other.numDigits;p++)
	{
	  temp=other.digits[other.numDigits-1-p]*this->digits[numDigits-1-n]+prodArray[resultSize-p-n-1];
	  temp=temp+carry;
	  carry=temp/10;
	  
	  prodArray[resultSize-1-p-n]=temp%10;	 
	}
      prodArray[resultSize-1-other.numDigits-n]=carry;
    }
  removeLeadingZeros(prodArray,resultSize);
  ReallyLongInt product(prodArray, resultSize, isNeg);
  return product;
}

void ReallyLongInt::absDiv(const ReallyLongInt& other, ReallyLongInt& quotient, ReallyLongInt& remainder) const
{
  quotient=0;
  remainder=0;
  cout<<remainder*10;
  for (unsigned int i=0; i<this->numDigits;i++)
    {
      remainder=remainder*10;
      remainder=remainder+this->digits[i];
      char d=0;
      while(!(other.absGreater(remainder)))
	{	 
	  remainder=remainder.absSub(other);
	  d=d+1;	 
	}
     
      quotient=(quotient * 10) +d;
    }

  cout<<quotient;
}



bool ReallyLongInt::greater(const ReallyLongInt& other) const
{
  cout<<this->isNeg<<" "<<other.isNeg<<endl;
  if (this->isNeg==true && other.isNeg==false)
    {
      cout<<"This is cout 1"<<endl;
      return false;
    }
  if (this->isNeg==false && other.isNeg==true)
    {
      cout<<"This is cout 2"<<endl;
      return true;
    }
  if(this->isNeg==true && other.isNeg==true)
    {
      return other.absGreater(*this);
    }
  else
    {
      cout<<"This is cout 3"<<endl;
      return absGreater(other);
    }
}
ReallyLongInt& ReallyLongInt::  operator=(const ReallyLongInt& other)
{
  swap(other);
  return *this;    
}
void ReallyLongInt::flipSign()
{
  if (this->isNeg==true)
    {
      this->isNeg=false;
    }
  else if (this->numDigits==1 && this->digits[0]==0)
    {
      this->isNeg=true;
    }
  else
    {
      this->isNeg=true;
    }
}
ReallyLongInt& ReallyLongInt::operator+=(const ReallyLongInt& other)
{
  *this=this->add(other);
  return *this;
}

ReallyLongInt& ReallyLongInt::operator-=(const ReallyLongInt& other)
{
  *this=this->sub(other);
  return *this;
}
ReallyLongInt& ReallyLongInt::operator*=(const ReallyLongInt& other)
{
  *this=this->mult(other);
  return *this;   
}
/*ReallyLongInt& ReallyLongInt::operator/=(const ReallyLongInt& other)
{
  *this=this->div(other);
  return *this;    
}
*/
ReallyLongInt operator+(const ReallyLongInt& x, const ReallyLongInt& y)
{
  ReallyLongInt sum=x.add(y);
  return sum;
}
ReallyLongInt operator-(const ReallyLongInt& x, const ReallyLongInt& y)
{
  ReallyLongInt diff=x.sub(y);
  return diff;
}
 ReallyLongInt operator*(const ReallyLongInt& x, const ReallyLongInt& y)
{
  ReallyLongInt prod=x.mult(y);
  return prod;
}
ReallyLongInt operator/(const ReallyLongInt& x, const ReallyLongInt& y)
{
  ReallyLongInt quotient;
  ReallyLongInt rem;
  x.div(y,quotient,rem);
  return quotient;
}

ReallyLongInt& ReallyLongInt::operator%=(const ReallyLongInt& other)
{
  ReallyLongInt quotient;
  ReallyLongInt rem;
  this->div(other, quotient, rem);
  *this=rem;
  return *this;
    
}
ReallyLongInt operator%(const ReallyLongInt& x, const ReallyLongInt& y)
{
  ReallyLongInt quotient;
  ReallyLongInt rem;
  x.div(y, quotient, rem);
  return rem;
}
bool operator==(const ReallyLongInt& x, const ReallyLongInt& y)
{
  return x.equal(y);
}
bool operator!=(const ReallyLongInt& x, const ReallyLongInt& y)
{
  return x.equal(y);
}
bool operator>(const ReallyLongInt& x, const ReallyLongInt& y)
{
  return x.greater(y);
}
bool operator<(const ReallyLongInt& x, const ReallyLongInt& y)
{
  return y.greater(x);
}

bool operator>=(const ReallyLongInt& x, const ReallyLongInt& y)
{
   if (x.greater(y)  || x.equal(y))
    {
      return true;
    }
  else 
    return false;
}
bool operator<=(const ReallyLongInt& x, const ReallyLongInt& y)
{
   if (x.greater(y)  || x.equal(y))
    {
      return false;
    }
  else 
    return true;
}

ReallyLongInt& ReallyLongInt::operator++()
{
  ReallyLongInt w(1);
  *this=this->add(w);
  return *this;
}
ReallyLongInt& ReallyLongInt::operator--()
{
  ReallyLongInt q(1);
  *this=this->sub(q);
  return *this;
}
ReallyLongInt ReallyLongInt::operator++(int dummy)
{
  ReallyLongInt w(1);
  *this=this->add(w);
  return *this;
}
ReallyLongInt ReallyLongInt::operator--(int dummy)
{
   ReallyLongInt q(1);
  *this=this->sub(q);
  return *this;
}

ReallyLongInt ReallyLongInt::operator-() const
{
  ReallyLongInt neg=*this;
  neg.flipSign(); 
  return neg;
}
long long ReallyLongInt::toLongLong() const
{
  ReallyLongInt t=LLONG_MAX;
  t=t+1;
  ReallyLongInt r=(*this)%t;
  long long w=0;
  for (unsigned int i=0;i<r.numDigits;i++)
    {
      w=w*10;
      w=w+r.digits[i];
    }
  if (r.isNeg==true)
    {
      w=w*-1;
    }
  return w;
  
}
/*
int main(int argc, char** argv)
{
  ReallyLongInt quotient;
  ReallyLongInt rem;
  ReallyLongInt x ("123");
  ReallyLongInt y("12");
  ReallyLongInt z("1");
  x.absSub(y);
  //cout<<x++<<endl;
  cout<<y.toLongLong()<<endl;
  //x.absDiv(y,quotient,rem);
  return 0;
}

// Subtraction has the wrong sign value but works the other way around


*/




/*long long toLongLong() const
{
  
}
*/
//You have to implement a negation operator 
// Sub looks at sign and then calls abs sub and then potentially multiplies by negative arithmetic rules.

//
//implement flipSign

// DO NOT USE DIVISION OPERATION IN DIVISION USE ONLY OPERATIONS BUILT BEFORE HAND.
//R=remainder
// d= individual digits of quotient
// q=quotient
//y=is the number denominator
//x=numerator




// test flip sign
//ask about negation:: Make a copy of this object and then call flip sign and return the flipped object
// test your 


//why is divison void
//
//do i have access to remainder for the % operator
