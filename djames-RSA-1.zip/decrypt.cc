#include <iostream>
#include <string>
#include<fstream>
#include"numberTheory.h"
#include "ReallyLongInt.h"
using namespace std;

int main(int argc, char** argv)
{
   if(argc <  2)
     {
       cout<< "There are not enough arguments to carry out the decryption"<< endl;
       return 0;
     }
   string e;
   string n;
   ifstream fin(argv[1]);
   fin>>e;
   fin>>n;
   ifstream encrypt(argv[2]);
   ofstream fout(argv[3]);
   string c;
   ReallyLongInt r(e);
   ReallyLongInt t(n);
   encrypt>>c;
   ReallyLongInt k(c);
   //k.toLongLong();
   while (!encrypt.eof())
     {
      char y=modPower(k,r,t).toLongLong();
      fout<<(char)y;
      encrypt>>c;
     }
   return 0;
}
