#include <iostream>
#include <string>
#include<fstream>
#include"numberTheory.h"
#include <cstdlib>
#include <climits>
#include "ReallyLongInt.h"
#include <cmath>
#include <cstdlib>

using namespace std;

int main(int argc, char** argv)
{
  if (argc< 4)
    {
      cout<<"There are not enough arguments to carry out the encryption"<<endl;
      return 0;
    }
  ReallyLongInt p(argv[1]); 
  ReallyLongInt q(argv[2]);
  if (p>100000||q>100000)
    {
      cout<<"primality is not being verified"<<endl;
      return 0;
    }
  ReallyLongInt x;
  ReallyLongInt y;
 
  if (isPrime(p) || isPrime(q))
    {
      cout<<"These numbers are not prime numbers"<<endl;
      return 1;
    }
  ReallyLongInt n=p*q;
  ReallyLongInt t=(p-1)*(q-1);
  ReallyLongInt e=1;
  ReallyLongInt i=2;
  ReallyLongInt d;
  while(e<t and e==1)
    {
      ReallyLongInt gcd=extendedEuclid(i,t,&x, &y);
      if (gcd==1)
	{
	  e=i;
	  //cout<<"I am in the loop and making changes"<<endl;
	  d=x;
	}    
      i++; 
    }
  
  if (d<0)
    {
       d=d+t;
    }
   ofstream pub(argv[3]);
   ofstream pri(argv[4]);
   pub<<e<<" "<<n<<endl;
   pri<<d<<" "<< n<<endl;
   return 0;
}
