#ifndef modpower_h
#define modPower_h

#include <string>
#include <ostream>
#include <cmath>
#include <cstdlib>
#include "ReallyLongInt.h"
#include <iostream>
#include <climits>

using namespace std;

ReallyLongInt modPower(const ReallyLongInt& base, const ReallyLongInt& exponent, const ReallyLongInt& mod);

bool isPrime(const ReallyLongInt& num);

ReallyLongInt extendedEuclid (const ReallyLongInt& a, const ReallyLongInt& b, ReallyLongInt* px, ReallyLongInt * py);

#endif
