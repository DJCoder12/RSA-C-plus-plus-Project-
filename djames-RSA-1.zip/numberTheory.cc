#include <iostream>
#include <string>
#include<fstream>
#include"numberTheory.h"
#include <cmath>
#include <cstdlib>
#include "ReallyLongInt.h"

#include <iostream>
#include <climits>

using namespace std;
ReallyLongInt modPower(const ReallyLongInt& base, const ReallyLongInt& exponent,const ReallyLongInt& mod)
{
 
  if (exponent==1)
    {
      return base%mod;
    }
  else if(exponent%2==1)
    {
      //exponent=exponent/2;
      ReallyLongInt baseFactor=modPower(base,exponent/2,mod);
      ReallyLongInt modVal= ((base%mod) * (baseFactor%mod) * (baseFactor%mod)%mod) ; 
      
      return modVal;
         
    }

  else if (exponent%2==0 && exponent!=0)
    {
      
      //exponent=exponent/2;
      ReallyLongInt baseFactor=modPower(base,exponent/2,mod);
      ReallyLongInt modVal= ((baseFactor) *(baseFactor))%mod;  
      return modVal;
    } 
  
  else if (exponent==0)
    {
      return 1%mod;
    }
  return 0;
}

bool isPrime(const ReallyLongInt& num)
{
  ReallyLongInt test=num/2;
  for (ReallyLongInt i=num/2;i>2;i--)
    {
      if (num%i==0)
	{
	  return 1   ;
	}
      else
	return 0;
    }
  return 0;
}

ReallyLongInt extendedEuclid (const ReallyLongInt& a, const ReallyLongInt& b, ReallyLongInt* px, ReallyLongInt * py)
{
  ReallyLongInt x;
  ReallyLongInt y;
  if (b==0)
    {
      x=1;
      y=0;
      *px=x;
      *py=y;       
      return (a);
    }
  else
    {
      ReallyLongInt d=extendedEuclid(b, a%b, &x,&y);
      *px=y;
      *py=x-y *a/b;
      return (d);
    }
}

