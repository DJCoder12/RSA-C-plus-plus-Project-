#include <iostream>
#include <string>
#include<fstream>
#include"numberTheory.h"
#include <climits>
#include "ReallyLongInt.h"
#include <cmath>
using namespace std;

int main(int argc, char** argv)
{
  cout<<"I have started the correct encrypt"<<endl;
  
  if(argc <  4)
    {
      cout<< "There are not enough arguments to carry out the encryption"<< endl;
      return 0;
    }
  string e;
  string n;
  ifstream fin(argv[1]);
  fin>>e;
  fin>>n;
  cout<<"I read the values for encryption"<<endl;
  ReallyLongInt r(e);
  ReallyLongInt v(n);
  cout<<"I made the rlints"<<endl;
  ifstream platxt(argv[2]);
  ofstream fout(argv[3]);
  char c;
  cout<<"I am right before the actual loop"<<endl;
  while (platxt.get(c))
    {
      ReallyLongInt y=modPower(c,r,v);
      fout<<y<<endl;
    }

  return 0;
}
