#include <string>
#include <ostream>
#include <cmath>
#include <cstdlib>
#include "ReallyLongInt.h"
#include <iostream>
#include <climits>

using namespace std;
ReallyLongInt factorial(ReallyLongInt x)
{
  ReallyLongInt total(1);
  
  ReallyLongInt checker=x;
  while(checker>1)
    {
      total=total.mult(checker);
      checker--;
      
    }
  cout<<"this is the print of the total YEEEAAAAH BOI"<<endl;
  cout<<total<<endl;
  return total;
}

int main(int argc, char** argv)
{
  factorial(11);
  return 0;
}
